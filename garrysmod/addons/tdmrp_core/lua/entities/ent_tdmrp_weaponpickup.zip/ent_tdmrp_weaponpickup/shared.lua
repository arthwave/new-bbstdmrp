ENT.Type        = "anim"
ENT.Base        = "base_anim"
ENT.PrintName   = "TDMRP Weapon Pickup"
ENT.Spawnable   = false

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "WeaponClass")
end
