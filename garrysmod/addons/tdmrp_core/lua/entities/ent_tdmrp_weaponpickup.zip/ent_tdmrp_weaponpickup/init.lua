AddCSLuaFile("shared.lua")
include("shared.lua")

TDMRP = TDMRP or {}

function ENT:Initialize()
    self:SetModel(self:GetModel() or "models/props_junk/cardboard_box001a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end
end

function ENT:Use(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local class = self:GetWeaponClass()
    if not class or class == "" then return end

    local wep = ply:Give(class)

    -- If there is a TDMRP instance attached to this pickup, apply it
    if IsValid(wep) and self.TDMRP_InstanceID and TDMRP.GetWeaponInstance and TDMRP.ApplyInstanceToSWEP then
        local inst = TDMRP.GetWeaponInstance(self.TDMRP_InstanceID)
        if inst then
            TDMRP.ApplyInstanceToSWEP(wep, inst)
            wep.TDMRP_InstanceID = inst.id
        end
    end

    self:Remove()
end
